﻿using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace AUV_GCS
{
    internal class SubComponentGroup
    {
        public string Name { get; set; }
        public int Count { get; set; }
        public Dictionary<string, string> Properties { get; set; }
        public SubComponent[] subComponents { get; set; }

        public SubComponentGroup(string Name, int Count, JObject Properties)
        {
            this.Name = Name;
            this.Count = Count;
            this.Properties = new Dictionary<string, string>();
            this.subComponents = new SubComponent[Count];

            foreach (KeyValuePair<string, JToken> stat in Properties)
            {
                this.Properties[stat.Key] = (string)stat.Value;
            }
        }

        public void createComponentPanels()
        {

        }
    }
}

﻿using System.Windows.Forms;
using System.Collections.Generic;

namespace AUV_GCS
{
    internal class SubComponent
    {
        public Panel pnlGroup { get; set; }
        public Label lblName { get; set; }
        public List<Label> lblStatName { get; set; }
        public List<Label> lblValue { get; set; }

        private string name;
        private float[] values;

        public SubComponent(string name)
        {
            this.name = name;
            this.lblName.Text = this.name;
        }

        public List<Label> LblStatName { get => lblStatName; set => lblStatName = value; }

        public float[] getValues()
        {
            return values;
        }

        public void updateValues(int index = -1)
        {
            if (index < -1 || index >= lblValue.Count)
            {
                return;
            }

            if (index == -1)
            {
                for (int i = 0; i < this.lblValue.Count; i++)
                {
                    this.lblValue[i].Text = string.Format("{0:N2}", this.values[i]);
                }
            }
            else
            {
                this.lblValue[index].Text = string.Format("{0:N2}", this.values[index]);
            }

        }
    }
}

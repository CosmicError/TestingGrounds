﻿namespace AUV_GCS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlComponentInfoDisplay = new System.Windows.Forms.Panel();
            this.tblComponentGroupTable = new System.Windows.Forms.TableLayoutPanel();
            this.pnlComponentGroup = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblStatName = new System.Windows.Forms.Label();
            this.lblStatValue = new System.Windows.Forms.Label();
            this.lblComponentName = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pnlCriticalIndicators = new System.Windows.Forms.Panel();
            this.lblVoltage = new System.Windows.Forms.Label();
            this.txtConsole = new System.Windows.Forms.TextBox();
            this.picVideoDisplay = new System.Windows.Forms.PictureBox();
            this.cboComponentGroups = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabMain.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlComponentInfoDisplay.SuspendLayout();
            this.tblComponentGroupTable.SuspendLayout();
            this.pnlComponentGroup.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.pnlCriticalIndicators.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picVideoDisplay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPage1);
            this.tabMain.Controls.Add(this.tabPage2);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.Padding = new System.Drawing.Point(3, 3);
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(1264, 681);
            this.tabMain.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightGoldenrodYellow;
            this.tabPage1.Controls.Add(this.chart1);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.pnlComponentInfoDisplay);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.pnlCriticalIndicators);
            this.tabPage1.Controls.Add(this.txtConsole);
            this.tabPage1.Controls.Add(this.picVideoDisplay);
            this.tabPage1.Controls.Add(this.cboComponentGroups);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1256, 655);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.DarkTurquoise;
            this.pictureBox1.Location = new System.Drawing.Point(966, 254);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(287, 153);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // pnlComponentInfoDisplay
            // 
            this.pnlComponentInfoDisplay.AutoScroll = true;
            this.pnlComponentInfoDisplay.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlComponentInfoDisplay.BackColor = System.Drawing.Color.Gold;
            this.pnlComponentInfoDisplay.Controls.Add(this.tblComponentGroupTable);
            this.pnlComponentInfoDisplay.Location = new System.Drawing.Point(6, 40);
            this.pnlComponentInfoDisplay.Name = "pnlComponentInfoDisplay";
            this.pnlComponentInfoDisplay.Padding = new System.Windows.Forms.Padding(3);
            this.pnlComponentInfoDisplay.Size = new System.Drawing.Size(214, 607);
            this.pnlComponentInfoDisplay.TabIndex = 5;
            // 
            // tblComponentGroupTable
            // 
            this.tblComponentGroupTable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tblComponentGroupTable.AutoSize = true;
            this.tblComponentGroupTable.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.tblComponentGroupTable.ColumnCount = 1;
            this.tblComponentGroupTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblComponentGroupTable.Controls.Add(this.pnlComponentGroup, 0, 0);
            this.tblComponentGroupTable.Location = new System.Drawing.Point(6, 6);
            this.tblComponentGroupTable.Name = "tblComponentGroupTable";
            this.tblComponentGroupTable.Padding = new System.Windows.Forms.Padding(0, 0, 0, 2);
            this.tblComponentGroupTable.RowCount = 1;
            this.tblComponentGroupTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblComponentGroupTable.Size = new System.Drawing.Size(203, 52);
            this.tblComponentGroupTable.TabIndex = 1;
            // 
            // pnlComponentGroup
            // 
            this.pnlComponentGroup.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlComponentGroup.AutoSize = true;
            this.pnlComponentGroup.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlComponentGroup.BackColor = System.Drawing.Color.SkyBlue;
            this.pnlComponentGroup.Controls.Add(this.tableLayoutPanel2);
            this.pnlComponentGroup.Controls.Add(this.lblComponentName);
            this.pnlComponentGroup.Location = new System.Drawing.Point(3, 3);
            this.pnlComponentGroup.Name = "pnlComponentGroup";
            this.pnlComponentGroup.Size = new System.Drawing.Size(197, 44);
            this.pnlComponentGroup.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.lblStatName, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblStatValue, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 21);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(201, 21);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // lblStatName
            // 
            this.lblStatName.AutoSize = true;
            this.lblStatName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblStatName.Location = new System.Drawing.Point(3, 0);
            this.lblStatName.Name = "lblStatName";
            this.lblStatName.Size = new System.Drawing.Size(94, 21);
            this.lblStatName.TabIndex = 0;
            this.lblStatName.Text = "label3";
            this.lblStatName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblStatValue
            // 
            this.lblStatValue.AutoSize = true;
            this.lblStatValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblStatValue.Location = new System.Drawing.Point(103, 0);
            this.lblStatValue.Name = "lblStatValue";
            this.lblStatValue.Size = new System.Drawing.Size(95, 21);
            this.lblStatValue.TabIndex = 1;
            this.lblStatValue.Text = "label4";
            this.lblStatValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblComponentName
            // 
            this.lblComponentName.AutoSize = true;
            this.lblComponentName.Location = new System.Drawing.Point(80, 5);
            this.lblComponentName.Name = "lblComponentName";
            this.lblComponentName.Size = new System.Drawing.Size(49, 13);
            this.lblComponentName.TabIndex = 0;
            this.lblComponentName.Text = "Battery 0";
            this.lblComponentName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.DarkTurquoise;
            this.pictureBox2.Location = new System.Drawing.Point(966, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(287, 245);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pnlCriticalIndicators
            // 
            this.pnlCriticalIndicators.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlCriticalIndicators.BackColor = System.Drawing.Color.MediumOrchid;
            this.pnlCriticalIndicators.Controls.Add(this.lblVoltage);
            this.pnlCriticalIndicators.Location = new System.Drawing.Point(226, 425);
            this.pnlCriticalIndicators.Name = "pnlCriticalIndicators";
            this.pnlCriticalIndicators.Size = new System.Drawing.Size(734, 28);
            this.pnlCriticalIndicators.TabIndex = 3;
            // 
            // lblVoltage
            // 
            this.lblVoltage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.lblVoltage.AutoSize = true;
            this.lblVoltage.Location = new System.Drawing.Point(4, 6);
            this.lblVoltage.Name = "lblVoltage";
            this.lblVoltage.Size = new System.Drawing.Size(35, 13);
            this.lblVoltage.TabIndex = 0;
            this.lblVoltage.Text = "label1";
            // 
            // txtConsole
            // 
            this.txtConsole.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtConsole.BackColor = System.Drawing.Color.LightGreen;
            this.txtConsole.Location = new System.Drawing.Point(226, 459);
            this.txtConsole.Multiline = true;
            this.txtConsole.Name = "txtConsole";
            this.txtConsole.Size = new System.Drawing.Size(734, 188);
            this.txtConsole.TabIndex = 2;
            // 
            // picVideoDisplay
            // 
            this.picVideoDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picVideoDisplay.BackColor = System.Drawing.Color.IndianRed;
            this.picVideoDisplay.Location = new System.Drawing.Point(226, 6);
            this.picVideoDisplay.Name = "picVideoDisplay";
            this.picVideoDisplay.Size = new System.Drawing.Size(734, 413);
            this.picVideoDisplay.TabIndex = 1;
            this.picVideoDisplay.TabStop = false;
            this.picVideoDisplay.Click += new System.EventHandler(this.picVideoDisplay_Click);
            // 
            // cboComponentGroups
            // 
            this.cboComponentGroups.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboComponentGroups.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboComponentGroups.FormattingEnabled = true;
            this.cboComponentGroups.Location = new System.Drawing.Point(6, 6);
            this.cboComponentGroups.Name = "cboComponentGroups";
            this.cboComponentGroups.Size = new System.Drawing.Size(214, 28);
            this.cboComponentGroups.TabIndex = 0;
            this.cboComponentGroups.Text = "None";
            this.cboComponentGroups.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1256, 655);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(967, 254);
            this.chart1.Name = "chart1";
            series2.BorderWidth = 3;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.StepLine;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(286, 153);
            this.chart1.TabIndex = 7;
            this.chart1.Text = "chart1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.tabMain);
            this.MinimumSize = new System.Drawing.Size(1280, 39);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabMain.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlComponentInfoDisplay.ResumeLayout(false);
            this.pnlComponentInfoDisplay.PerformLayout();
            this.tblComponentGroupTable.ResumeLayout(false);
            this.tblComponentGroupTable.PerformLayout();
            this.pnlComponentGroup.ResumeLayout(false);
            this.pnlComponentGroup.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.pnlCriticalIndicators.ResumeLayout(false);
            this.pnlCriticalIndicators.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picVideoDisplay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.ComboBox cboComponentGroups;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel pnlCriticalIndicators;
        private System.Windows.Forms.Label lblVoltage;
        private System.Windows.Forms.TextBox txtConsole;
        private System.Windows.Forms.PictureBox picVideoDisplay;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel pnlComponentInfoDisplay;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TableLayoutPanel tblComponentGroupTable;
        private System.Windows.Forms.Panel pnlComponentGroup;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblStatName;
        private System.Windows.Forms.Label lblStatValue;
        private System.Windows.Forms.Label lblComponentName;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
    }
}


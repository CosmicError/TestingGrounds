﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AUV_GCS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        internal void loadCBOSelections(Config cfg)
        {
            cboComponentGroups.Items.AddRange(cfg.Robot.Keys.ToArray());
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*public string[] componentsList; //this represents the list of all components retrieved from the config file
            if (sender is ComboBox)
            {
                ComboBox cboComponent = sender as ComboBox;
                

            }*/
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void picVideoDisplay_Click(object sender, EventArgs e)
        {

        }

        private void pnlComponentInfo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

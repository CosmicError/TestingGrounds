﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace AUV_GCS
{
    internal class Config
    {
        public Dictionary<string, SubComponentGroup> Robot { get; set; }
        public Dictionary<string, string> Assets { get; set; }
        public Dictionary<string, bool> Errors { get; set; }

        public Config() {
            this.Robot = new Dictionary<string, SubComponentGroup>();
            this.Assets = new Dictionary<string, string>();
            this.Errors = new Dictionary<string, bool>();
        }

        public void intitDynamic(dynamic jsonDynamic)
        {
            foreach (JProperty section in jsonDynamic)
            {
                switch (section.Name)
                {
                    case "ROBOT":
                        // temp list dict before we get the group names
                        List<Dictionary<string, dynamic>> r = new List<Dictionary<string, dynamic>>();
                        foreach (JObject group in section.Value)
                        {
                            Dictionary<string, dynamic> s = new Dictionary<string, dynamic>();
                            foreach (KeyValuePair<string, JToken> stat in group)
                            {
                                s[stat.Key] = stat.Value;
                            }
                            SubComponentGroup scg = new SubComponentGroup((string)s["Name"], (int)s["Count"], s["Properties"]);
                            this.Robot[(string)s["Name"]] = scg; // Now that we've gotten the name, we just make the overall key, the name
                        }
                        break;
                    case "ASSETS":
                        foreach (JProperty asset in section.Value)
                        {
                            Console.WriteLine(asset.ToString());
                            this.Assets[(string)asset.Name] = (string) asset.Value;
                        }
                        break;
                    case "ERRORS":
                        foreach (JProperty asset in section.Value)
                        {
                            Console.WriteLine(asset.ToString());
                            this.Assets[(string)asset.Name] = (string)asset.Value;
                        }
                        break;
                    default:
                        throw new Exception("Config Section Not Found");
                }
            }
        }
    }
}

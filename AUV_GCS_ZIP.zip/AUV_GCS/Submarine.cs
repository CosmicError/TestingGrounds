﻿using Renci.SshNet;
using Renci.SshNet.Common;
using System.Runtime.InteropServices;

namespace AUV_GCS
{
    // I'm just gonna merge the ssh connection and the submarine class to keep it "secure" (i have no idea what im doing)
    internal class Submarine
    {
        // link for the ssh work im gonna need to do to send commands to the submarine
        // https://stackoverflow.com/questions/11169396/c-sharp-send-a-simple-ssh-command
        public bool active;
        public bool sshConnected;

        public int depth;
        public int humidity;
        public int tubeTemp;
        public int orinTemp;

        private SshClient sshConnection;
        private string host;
        private int port;
        private string user;
        private string pass;

        public SshCommand startSub;
        public SshCommand logState;
        public SshCommand stopSub;

        public Submarine(string host, int port, string user, string pass)
        {

            active = false;
            sshConnected = false;
            this.host = host;
            this.port = port;
            this.user = user;
            this.pass = pass;
        }
        public void connectSSH()
        {
            if (!sshConnected)
            {
                sshConnection = new SshClient(this.host, this.port, this.user, this.pass);
                sshConnection.Connect();
                sshConnected = true;
            }
        }

        public void disconnectSSH()
        {
            if (sshConnected)
            {
                sshConnection.Disconnect();
                sshConnection.Dispose();
                sshConnected = false;
            }
        }

        public void initCommands()
        {
            // Maybe combine start and stop submarine if possible through a custom toggle system?
            this.startSub = sshConnection.CreateCommand("");
            this.stopSub = sshConnection.CreateCommand("");
            this.logState = sshConnection.CreateCommand("");
        }


    }
}

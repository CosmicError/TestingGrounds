﻿using Newtonsoft.Json;
using System;
using System.Windows.Forms;

namespace AUV_GCS
{

    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Form1 ui = new Form1();
            Config cfg = initConfig(@"C:\Users\Jack\Documents\Code\2023-2024\configs\surface.json");
            ui.loadCBOSelections(cfg);

            Application.Run(ui);
        }

        internal static Config initConfig(string path)
        {
            string json = System.IO.File.ReadAllText(path);
            var rawData = JsonConvert.DeserializeObject<dynamic>(json);
            Config c = new Config();
            c.intitDynamic(rawData);
            return c;
        }
    }
}
